# G33_INTE

Folder G33RGL contains the maven Pom.xml and the correct file/direcotry pathing for it to work properly on cmd.

To run
mvn verify 
or
mvn test

**** Make sure your CMD is on the correct directory (G33RGL). 

RGL_G33_java_Code is the directory you can also work on, if maven is not working properly, however there is a risk you can run into issues about compatibility for others or for yourself.
